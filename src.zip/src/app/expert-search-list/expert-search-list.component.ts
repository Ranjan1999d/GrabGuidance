import { Component, Inject, OnDestroy, OnInit, PLATFORM_ID } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
import { ApiService } from 'src/services/api.service';
import { DataService } from 'src/services/data.service';
import { searchCriteria } from '../models/expert.service.model';
import { isPlatformBrowser } from '@angular/common';
import { Title, Meta } from '@angular/platform-browser';

declare let ga: Function;

@Component({
	selector: 'app-expert-search-list',
	templateUrl: './expert-search-list.component.html',
	styleUrls: [ './expert-search-list.component.css' ]
})
export class ExpertSearchListComponent implements OnInit, OnDestroy {
	showSearchList: boolean;
	showBookNowBtn: boolean;
	subject: string;
	class: string;
	activatedClass: string;
	activatedSubject: string;
	expertCount: number;
	isLoggedIn: string;
	userId: any;
	selectedSortBy: string = 'None';
	selectedPrize: string = 'All';
	selectedLanguage: string = 'Any';
	selectedAccessbility: string = 'Everyone';
	selectedGender: any = 0;
	sortByCriteria: string[];
	userType: string;
	prizeCriteria: string[];
	languageCritria: string[];
	accessibilityCriteria: string[];
	genderCriteria: any[];
	start: number = 0;
	end: number = 15;
	searchCriteria: searchCriteria;
	searchCount: number;
	filterCount: number;
	searchObject: Subscription;
	expertsList: any[] = [];
	filterObj: any = {};
	expert_Id: any;
	constructor(
		private title: Title,
		private meta: Meta,
		private router: Router,
		private apiService: ApiService,
		private dataService: DataService,
		private tostr: ToastrService,
		private routerAct: ActivatedRoute,
		@Inject(PLATFORM_ID) private platformId: Object
	) {}

	ngAfterViewInit(): void {
		this.router.events.subscribe((event) => {
			// I check for isPlatformBrowser here because I'm using Angular Universal, you may not need it
			if (event instanceof NavigationEnd && isPlatformBrowser(this.platformId)) {
				console.log(ga); // Just to make sure it's actually the ga function
				ga('set', 'page', event.urlAfterRedirects);
				ga('send', 'pageview');
			}
		});
	}

	ngOnInit(): void {
		let roleObj: any = null;
		let classObj: any = null;
		let activatedRouteCriteria: any;
		this.routerAct.params.subscribe((data) => {
			if (data.searchedClass && data.searchedClass != 'all-classes') {
				let classData = this.dataService.classes.filter((c) => {
					return c.class == data.searchedClass.split('-')[1];
				});
				classObj = classData[0].id_class + '-' + classData[0].class_name;
				this.activatedClass = classData[0].class;
			}

			if (data.searchedSubject) {
				let sub: any = data.searchedSubject.split('-').join(' ');
				this.activatedSubject = sub;
				let academicSub = this.dataService.acadmicSubject.filter((acdemic) => {
					return acdemic.subject_name == sub;
				});
				if (academicSub.length > 0) {
					roleObj = {
						id: academicSub[0].id_subject,
						name: academicSub[0].subject_name,
						role: 'Academic'
					};
				} else {
					let carrerSub = this.dataService.careerSubject.filter((carrer) => {
						return carrer.guidance_name == sub;
					});
					if (carrerSub.length > 0) {
						roleObj = {
							id: carrerSub[0].id_guidance,
							name: carrerSub[0].guidance_name,
							role: 'Career'
						};
					}
				}
			}
			activatedRouteCriteria = {
				class: classObj,
				roleObj: roleObj
			};
			if (this.activatedClass == '10th' && this.activatedSubject == 'Maths') {
				this.title.setTitle('Get Online Experts For 10th Class Maths | April 2022');
				this.meta.updateTag({
					name: 'description',
					content:
						'We have India’s top experts to help you with your 10th class maths queries and doubts. There are live 1:1 sessions. So go ahead a book a session with us!'
				});
				this.meta.updateTag({
					name: 'keywords',
					content:
						'cbse online maths class 10, online class 10 maths, online classes for class 10 maths, online math class 10, 10th class online classes maths, maths cbse online class 10, class 10 maths cbse online, class 10 cbse online maths'
				});
			} else if (this.activatedClass == '11th' && this.activatedSubject == 'Maths') {
				this.title.setTitle('Book a Session With Best Experts For Online Class 11th Maths');
				this.meta.updateTag({
					name: 'description',
					content:
						'We have the leading experts onboard to help you with your class 11th maths doubts through interactive live sessions.So do not wait anymore and book now!.'
				});
				this.meta.updateTag({
					name: 'keywords',
					content:
						'cbse online class 11 maths, online class 11th maths, online classes for class 11 maths cbse'
				});
			} else if (this.activatedClass == '12th' && this.activatedSubject == 'Maths') {
				this.title.setTitle('Get 12th Maths Online Classes From Leading Experts | April 2022');
				this.meta.updateTag({
					name: 'description',
					content:
						'Book a session for 12th maths online classes with experienced teachers to help you with your doubts. You can choose the expert of your choice from the list.'
				});
				this.meta.updateTag({
					name: 'keywords',
					content:
						'12th maths online classes, best online classes for class 12 maths, class 12 maths online classes, online classes for class 12 maths, online class 12 maths'
				});
			} else if (this.activatedClass == '10th' && this.activatedSubject == 'Science') {
				this.title.setTitle('Get Experts For Online Class 10th Science | April 2022');
				this.meta.updateTag({
					name: 'description',
					content:
						'Top leading teachers with years of expertise to help you with your online class 10th science queries. There are live 1:1 sessions. So, go ahead and book now!'
				});
				this.meta.updateTag({
					name: 'keywords',
					content:
						'cbse online science class 10, online class 10 science, class 10 science cbse online, class 10 cbse online science, science class 10 cbse online, cbse online 10 science, online class 10th science, cbse online class 10th science'
				});
			} else if (this.activatedClass == '11th' && this.activatedSubject == 'Physics') {
				this.title.setTitle('Book Online Classes For Class 11 Physics With Our Top Experts');
				this.meta.updateTag({
					name: 'description',
					content:
						'Book online classes for class 11 physics with experienced teachers to help you understand the concepts & clear your doubts. All classes are live & interactive.'
				});
				this.meta.updateTag({
					name: 'keywords',
					content:
						'class 11 physics online classes, online physics classes for class 11, best online classes for class 11 physics, physics class 11 online classes, online class 11 physics'
				});
			} else if (this.activatedClass == '11th' && this.activatedSubject == 'Chemistry') {
				this.title.setTitle('Book Online Classes For Class 11th Chemistry With Our Experts ');
				this.meta.updateTag({
					name: 'description',
					content:
						'Top experts for online classes of class 11th chemistry. Live 1:1 interactive sessions to help you solve the queries & understand the concepts. Call Us Now!.'
				});
				this.meta.updateTag({
					name: 'keywords',
					content:
						'online chemistry classes for class 11, class 11 chemistry online classes, chemistry class 11 online classes'
				});
			} else if (this.activatedClass == '11th' && this.activatedSubject == 'Biology') {
				this.title.setTitle('Get Experts For Online Classes Of Class 11th Biology | April 2022');
				this.meta.updateTag({
					name: 'description',
					content:
						'Leading experts for online classes of class 11th Biology.Sessions are live & interactive to help you solve the queries & understand the concepts. Call Us Now!.'
				});
				this.meta.updateTag({ name: 'keywords', content: 'class 11th biology online classes' });
			} else if (this.activatedClass == '11th' && this.activatedSubject == 'Accounts') {
				this.title.setTitle('Get Online Classes For Class 11th Accounts From Best Experts');
				this.meta.updateTag({
					name: 'description',
					content:
						'India’s top experts for online classes of class 11th accounts to help you with your queries, doubts & help you in deep understanding of concepts. Call us now!'
				});
				this.meta.updateTag({
					name: 'keywords',
					content: 'online classes for class 11 accounts, accounts online classes class 11'
				});
			} else if (this.activatedClass == '12th' && this.activatedSubject == 'Physics') {
				this.title.setTitle('Get Online Classes For 12 Physics With Best Experts | April 2022');
				this.meta.updateTag({
					name: 'description',
					content:
						'We have India’s top physics experts to help you with your queries & make you understand the concepts better through live 1:1 sessions. Go ahead & book now!'
				});
				this.meta.updateTag({
					name: 'keywords',
					content:
						'online physics classes for class 12, physics class 12 online classes in hindi, class 12 physics online classes, physics class 12 online classes, 12th physics online class, online class 12 physics'
				});
			} else if (this.activatedClass == '12th' && this.activatedSubject == 'Chemistry') {
				this.title.setTitle('Get Online Classes For 12th Chemistry From Experts | April 2022');
				this.meta.updateTag({
					name: 'description',
					content:
						'India’s best chemistrty teachers to help you with your doubts & make you deeply understand the concepts through live 1:1 & interactive sessions. Book now!'
				});
				this.meta.updateTag({ name: 'keywords', content: 'class 12th chemistry live classes' });
			} else if (this.activatedClass == '12th' && this.activatedSubject == 'Biology') {
				this.title.setTitle('Best Online Classes For Class 12 Biology From Leading Experts');
				this.meta.updateTag({
					name: 'description',
					content:
						'Best experts for online classes of class 12 biology to help you understand the concepts & clear your doubts through live 1:1 & interactive sessions. Call us now!.'
				});
				this.meta.updateTag({ name: 'keywords', content: 'class 12th biology' });
			} else if (this.activatedClass == '12th' && this.activatedSubject == 'Accounts') {
				this.title.setTitle('Book With Our Top Experts Class 12th Accounts Online Classes');
				this.meta.updateTag({
					name: 'description',
					content:
						'Take class 12th accounts online classes with experienced teachers who will guide you & help you understand the root of concepts . Book a session with us!'
				});
				this.meta.updateTag({
					name: 'keywords',
					content:
						'class 12 accounts online classes, accountancy class 12 online classes, class 12 accountancy online classes, online classes for accounts class 12, 12th accounts online classes'
				});
			} else {
				this.title.setTitle('Best Online Sessions, Classes & Doubt Solving for Students | April 2022');
				this.meta.updateTag({
					name: 'keywords',
					content:
						'online classes, career guidance, academic counselling, live classes, career counselling,  job advising'
				});
				this.meta.updateTag({
					name: 'description',
					content:
						'Top Experts for your Online Sessions, Classes and Courses in India. Rightly designed and personalized to help you acquire, transform knowledge and grow. Call Us Now!.'
				});
			}
		});
		this.showSearchList = true;
		this.isLoggedIn = localStorage.getItem('isLoggedIn');
		this.userId = localStorage.getItem('id_user');
		this.userType = localStorage.getItem('user_role');
		if (isPlatformBrowser(this.platformId)) {
			this.selectedSortBy =
				sessionStorage.getItem('short_by') != null ? sessionStorage.getItem('short_by') : 'None';
			this.filterObj = JSON.parse(sessionStorage.getItem('filters'));
		}
		this.initializeFilter();
		this.sortByCriteria = this.dataService.getSortByOptions();
		this.prizeCriteria = this.dataService.getPrizeFilter();
		this.languageCritria = this.dataService.getLanguagesFilter();
		this.accessibilityCriteria = this.dataService.getSpecialAccesebilityFilter();
		this.genderCriteria = this.dataService.getGender();
		this.searchObject = this.dataService.searchCriteriaSub$.subscribe((criteria) => {
			if (criteria.class == null && criteria.roleObj == null) {
				criteria = activatedRouteCriteria;
			}
			this.dataService.truncateExpert();
			this.searchCriteria = criteria;
			this.getTheSearchedExpertList('');
		});
	}

	ngOnDestroy() {
		this.searchObject.unsubscribe();
	}

	getTheSearchedExpertList(type: string) {
		let searchCriteria = this.createSearchCriteria();
		let filter = this.createFilterCriteria();
		let short_by = this.createSortCriteria();
		let expert_ids = this.createExpertIds(type);
		this.apiService
			.searchExpert(
				searchCriteria.selectedClassId,
				searchCriteria.selectedRoleId,
				searchCriteria.selectedRoleName,
				filter,
				short_by,
				expert_ids,
				this.start,
				this.end,
				this.userId
			)
			.subscribe((data) => {
				if (data.code == 1000) {
					if (isPlatformBrowser(this.platformId)) {
						sessionStorage.setItem('searchedClass', searchCriteria.selectedClassValue);
						sessionStorage.setItem('searchedSubject', searchCriteria.selectedRoleSubject);

						localStorage.setItem('searchedClass', searchCriteria.selectedClassValue);
						localStorage.setItem('searchedSubject', searchCriteria.selectedRoleSubject);
					}

					this.subject = searchCriteria.selectedRoleSubject;
					if (type == 'load_more') {
						this.expertsList = this.expertsList.concat(data.experts);
					} else {
						this.expertsList = data.experts;
						this.searchCount = data.count;
						this.filterCount = data.filter;
					}
				}
			});
	}

	LoadMoreCount() {
		return this.expertsList.length < this.filterCount;
	}

	loadMoreData() {
		this.start = this.end;
		this.end = this.start + 15;
		// console.log("loadmor called");
		this.getTheSearchedExpertList('load_more');
	}

	createExpertIds(type: string) {
		if (type == 'load_more') {
			let expert_id = [];
			console.log(expert_id);
			this.expertsList.forEach((exp) => {
				expert_id.push(exp.id);
			});
			return expert_id;
		} else {
			return [];
		}
	}

	createSortCriteria() {
		if (this.selectedSortBy == 'Price - High To Low') {
			return 'price_high';
		}

		if (this.selectedSortBy == 'Price - Low To High') {
			return 'price_low';
		}

		if (this.selectedSortBy == 'By Rating') {
			return 'rating';
		}

		if (this.selectedSortBy == 'By Name') {
			return 'name';
		}

		if (this.selectedSortBy == 'Year Of Experience') {
			return 'experience';
		}

		return '';
	}

	createSearchCriteria() {
		let searchCriteria = {
			selectedClassId: null,
			selectedClassValue: null,
			selectedRoleId: null,
			selectedRoleName: 'all',
			selectedRoleSubject: null
		};

		if (this.searchCriteria && this.searchCriteria.class) {
			let selectedClassData = this.searchCriteria.class;
			let classData = selectedClassData.split('-');
			searchCriteria.selectedClassId = classData[0];
			searchCriteria.selectedClassValue = classData[1];
			this.class = searchCriteria.selectedClassValue;
		}

		if (this.searchCriteria && this.searchCriteria.roleObj) {
			let roleObj = this.searchCriteria.roleObj;
			searchCriteria.selectedRoleId = roleObj.id;
			searchCriteria.selectedRoleSubject = roleObj.name;
			searchCriteria.selectedRoleName = roleObj.role;
			this.subject = searchCriteria.selectedRoleSubject;
		}
		return searchCriteria;
	}

	initializeFilter() {
		for (let x in this.filterObj) {
			switch (x) {
				case 'language':
					this.selectedLanguage = this.filterObj[x];
					break;
				case 'accesebility':
					this.selectedAccessbility = this.filterObj[x];
					break;
				case 'gender':
					this.selectedGender = this.filterObj[x];
					break;
				case 'price':
					this.selectedPrize = this.createInitialPrice(this.filterObj[x]);
			}
		}
	}

	createInitialPrice(price: any) {
		let max = price.max;
		let min = price.min;

		if (max && !min) {
			return '< 250';
		}

		if (!max && min) {
			return '1000+';
		}

		if (min && max) {
			return min + '-' + max;
		}
	}

	createFilterCriteria() {
		let filter = {
			gender: '',
			language: '',
			accesebility: '',
			price: { max: '', min: '' }
		};

		if (this.selectedPrize == 'All') {
			delete filter.price;
		} else {
			filter.price = this.filterByPrice(this.selectedPrize);
		}

		if (this.selectedLanguage == 'Any') {
			delete filter.language;
		} else {
			filter.language = this.selectedLanguage;
		}

		if (this.selectedAccessbility == 'Everyone') {
			delete filter.accesebility;
		} else {
			filter.accesebility = this.selectedAccessbility;
		}

		if (this.selectedGender == 0) {
			delete filter.gender;
		} else {
			filter.gender = this.selectedGender;
		}
		this.filterObj = filter;
		return filter;
	}

	filterByPrice(priceFilter: string) {
		let price = { max: null, min: null };

		if (priceFilter == '< 250') {
			price.max = 249;
			delete price.min;
		}
		if (priceFilter == '250-500') {
			price.min = 250;
			price.max = 500;
		}

		if (priceFilter == '500-1000') {
			price.min = 500;
			price.max = 1000;
		}

		if (priceFilter == '1000+') {
			price.min = 1001;
			delete price.max;
		}
		return price;
	}

	applyFilter() {
		if (isPlatformBrowser(this.platformId)) {
			sessionStorage.setItem('filters', JSON.stringify(this.createFilterCriteria()));
			sessionStorage.setItem('short_by', this.selectedSortBy);

			localStorage.setItem('filters', JSON.stringify(this.createFilterCriteria()));
			localStorage.setItem('short_by', this.selectedSortBy);
		}
		this.getTheSearchedExpertList('');
	}

	totalFilterApplied() {
		let filter = this.createFilterCriteria();
		return Object.keys(filter).length;
	}

	clearFilters() {
		this.selectedSortBy = 'By Name';
		this.selectedPrize = 'All';
		this.selectedLanguage = 'Any';
		this.selectedAccessbility = 'Everyone';
		this.selectedGender = 0;
		if (isPlatformBrowser(this.platformId)) {
			sessionStorage.removeItem('filters');
			sessionStorage.removeItem('short_by');
			localStorage.removeItem('filters');
			localStorage.removeItem('short_by');
		}
		this.getTheSearchedExpertList('');
	}

	createImageUrl(data: string) {
		if (data) {
			return data;
		}
		return '../../assets/images/image.png';
	}

	gotoProfile(data: any) {
		this.showSearchList = false;
		let burl = data.name;
		let fg = burl.split(' ');
		let join = fg.join('-');
		if (isPlatformBrowser(this.platformId)) {
			window.open('/expert/' + data.id + '/' + join);
		}
	}

	bookmarkExpert(expert: any) {
		if (this.isLoggedIn) {
			if (this.userType == 'user') {
				let message = null;
				if (expert.selected == 1) {
					expert.selected = 0;
					message = 'Removed From Favourites';
				} else {
					expert.selected = 1;
					message = 'Saved To Favourites';
				}
				this.apiService.saveUserExpert(expert.id, this.userId, expert.selected).subscribe((data) => {
					if (data.code == 1000) {
						this.tostr.success(message);
					}
				});
			} else {
				alert(this.userType + ' are not allowed to save the experts');
			}
		} else {
			if (isPlatformBrowser(this.platformId)) {
				this.apiService.openExpertSignInModal('User signIn');
				sessionStorage.setItem('redirectUrl', this.router.url);
				localStorage.setItem('redirectUrl', this.router.url);
			}
		}
	}

	mouseEnter(rowData, value) {
		rowData.showBookNowBtn = true;
	}

	mouseLeave(rowData, value) {
		rowData.showBookNowBtn = false;
	}

	refresh(): void {
		if (isPlatformBrowser(this.platformId)) {
			window.location.reload();
		}
	}
}
