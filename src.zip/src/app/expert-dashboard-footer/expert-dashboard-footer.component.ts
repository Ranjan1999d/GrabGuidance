import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-expert-dashboard-footer',
  templateUrl: './expert-dashboard-footer.component.html',
  styleUrls: ['./expert-dashboard-footer.component.css']
})
export class ExpertDashboardFooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
