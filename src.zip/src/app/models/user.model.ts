export interface UserProfile {
  userId: string,
  name: string,
  email: string,
  phNumber: string,
  dob: string,
  gender: string,
  address:string,
  city:string,
  state:string,
  pincode:string,
  gstin:string

}
