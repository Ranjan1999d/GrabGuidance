export interface DocumentResponse {
   code: number,
   documents: object,
   status: string;
}
