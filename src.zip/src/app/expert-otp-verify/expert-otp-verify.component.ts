import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-expert-otp-verify',
  templateUrl: './expert-otp-verify.component.html',
  styleUrls: ['./expert-otp-verify.component.css']
})
export class ExpertOtpVerifyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
