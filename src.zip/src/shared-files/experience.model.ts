export class ExperienceModel{
    duration;
    designation;
    company_name;
}