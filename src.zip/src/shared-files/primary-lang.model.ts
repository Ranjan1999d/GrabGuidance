export const PrimaryLanguages = [
    {
        "languages": "Hindi"
    },
    {
        "languages": "English"
    },
    {
        "languages": "Malayalam"
    },
    {
        "languages": "Punjabi"
    },
    {
        "languages": "Gujarati"
    },
    {
        "languages": "Tamil"
    },
    {
        "languages": "Bangla"
    },
    {
        "languages": "Telugu"
    },
    {
        "languages": "Oriya"
    },
    {
        "languages": "Lushai"
    },
    {
        "languages": "Marathi"
    },
    {
        "languages": "Konkani"
    },
    {
        "languages": "Khasi"
    },
    {
        "languages": "Kannada"
    },
    {
        "languages": "Nepali"
    },
    {
        "languages": "Manipuri"
    },
    {
        "languages": "Assamese"
    },
    {
        "languages": "Nissi"
    }
]
