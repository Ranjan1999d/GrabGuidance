export class QualificationModel{
    school;
    degree;
    specialization;
    passed_year;
}