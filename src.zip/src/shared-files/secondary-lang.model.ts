export const SecondaryLanguages = [
    {
        "languages": "Only to Normal Users"
    },
    {
        "languages": "Speech Impairments"
    },
    {
        "languages": "Deaf"
    },
    {
        "languages": "Visual Impairments"
    }
]