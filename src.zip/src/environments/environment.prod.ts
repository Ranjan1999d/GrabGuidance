export const environment = {
  restUrl: 'https://api.grabguidance.com/',
  production: true
};
